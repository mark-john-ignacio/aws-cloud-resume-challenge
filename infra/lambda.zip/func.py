import boto3
import logging
import json
from decimal import Decimal

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"Received event: {event}")
    
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('cloud-resume-terraform')

        response = table.update_item(
            Key={
                'id': event['id']
            },
            UpdateExpression='ADD #v :inc',
            ExpressionAttributeNames={
                '#v': 'views'
            },
            ExpressionAttributeValues={
                ':inc': 1
            },
            ReturnValues="UPDATED_NEW"
        )

        views = int(response['Attributes']['views'])
        logger.info(f"Views updated successfully: {views}")
        return {
            'statusCode': 200,
            'body': json.dumps({'views': views})
        }

    except Exception as e:
        logger.error(f"Error updating views: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal server error'})
        }